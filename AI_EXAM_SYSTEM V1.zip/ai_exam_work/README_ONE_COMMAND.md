# AI Exam System - One Command Startup

## Requirements
- Windows 10/11
- Python 3.10+ (3.12+ recommended)
- Node.js LTS

Verify once:

```powershell
python --version
node --version
npm --version
```

## Start everything
Open PowerShell in this folder and run only:

```powershell
python run.py
```

Or double-click:

```text
START.bat
```

The runner automatically:
- finds Windows `npm.cmd`
- installs Student dependencies inside `student/`
- installs Admin dependencies inside `admin/`
- checks/installs backend Python packages
- starts FastAPI backend on port 8000
- starts Student Vite app on port 5173
- starts Admin Vite app on port 5174
- opens Student and Admin pages in the browser

## Login
Student: `student1 / student123`
Admin: `admin / admin123`

## URLs
- Student: http://localhost:5173
- Admin: http://localhost:5174
- Backend health: http://127.0.0.1:8000/health

## Important
Do NOT run `npm install` in the project root. The root has no `package.json`.
The runner installs dependencies separately in `student/` and `admin/`.

If Node.js was installed while PowerShell was already open, close PowerShell and open a new PowerShell window before running `python run.py` so the updated PATH is available.


### Python 3.14 / bcrypt compatibility
This version uses PBKDF2-SHA256 password hashing instead of passlib/bcrypt, so the backend avoids the bcrypt compatibility error on Python 3.14.
