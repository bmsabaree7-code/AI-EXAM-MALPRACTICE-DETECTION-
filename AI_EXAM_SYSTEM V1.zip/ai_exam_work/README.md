# AI Exam System — Student/Admin Separate Host Deployment

This package is arranged so the backend is hosted once and Student/Admin are hosted as separate frontend deployments.

Recommended final URLs:
- Student: https://YOUR-STUDENT-APP.vercel.app
- Admin: https://YOUR-ADMIN-APP.vercel.app
- Backend API: https://YOUR-BACKEND.onrender.com

The Student and Admin apps are separate folders but use the same API/database.

## 1) Deploy backend to Render

1. Push this project to GitHub.
2. Create a Render Web Service from the `backend` folder.
3. Build Command:
   pip install -r requirements.txt
4. Start Command:
   uvicorn app.main:app --host 0.0.0.0 --port $PORT
5. Add environment variables:
   SECRET_KEY=replace-with-a-long-random-secret
   DATABASE_URL=sqlite:///./exam.db
   CORS_ORIGINS=https://YOUR-STUDENT-APP.vercel.app,https://YOUR-ADMIN-APP.vercel.app
6. Deploy.
7. Open `/health` on the backend URL.
8. Run the seed endpoint once in a browser:
   https://YOUR-BACKEND.onrender.com/api/seed
   It creates demo accounts/questions.

Important: Render's local SQLite filesystem is not suitable for production persistence. For a real deployment, use Render PostgreSQL and set DATABASE_URL accordingly.

## 2) Deploy Student separately to Vercel

Create a Vercel project pointing to the `student` folder.

Environment variable:
VITE_API_URL=https://YOUR-BACKEND.onrender.com/api

Deploy. Student URL becomes a separate host.

## 3) Deploy Admin separately to Vercel

Create another Vercel project pointing to the `admin` folder.

Environment variable:
VITE_API_URL=https://YOUR-BACKEND.onrender.com/api

Deploy. Admin URL becomes another separate host.

## Demo accounts

Student:
student1 / student123

Admin:
admin / admin123

## Local test

Backend:
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

Student:
cd student
npm install
npm run dev

Admin:
cd admin
npm install
npm run dev


## Updated exam validation and monitoring
- Admin dashboard includes per-session total questions/marks, answered, unanswered, correct and wrong counts.
- Student sees the same validation summary after submitting.
- Face presence / multiple-face checks and heuristic head, lower-face motion and background-motion flags run with OpenCV.
- Optional YOLO object detection can flag common COCO objects such as cell phones, laptops, TVs and remotes. To enable it, use a compatible Python 3.11/3.12 environment and run `python -m pip install -r backend/optional_object_detection.txt`. The model may download on first use.
- The standard YOLO model does **not** reliably identify a phone back case without a visible phone, loose tiny bit papers, or headphones/earbuds. These require a specialized trained model and cannot be guaranteed by this ZIP. Motion flags can be false positives and must be reviewed by an administrator; they are not proof of cheating.
- Existing SQLite databases are migrated to add the answer-result snapshot column at startup.
