import os
import sys
import subprocess
import time
import shutil
import signal
import webbrowser
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
STUDENT = ROOT / "student"
ADMIN = ROOT / "admin"


def fail(message):
    print(f"\nERROR: {message}\n")
    raise SystemExit(1)


def npm_command():
    # Windows normally exposes npm through npm.cmd. npm.exe may also exist.
    for name in ("npm.cmd", "npm.exe", "npm"):
        path = shutil.which(name)
        if path:
            return path
    fail("Node.js/npm was not found in PATH. Close PowerShell, reopen it, verify `node --version` and `npm --version`, then run again.")


def validate_project():
    if sys.version_info < (3, 10):
        fail("Python 3.10+ is required. Python 3.12+ is recommended.")
    for folder, label in ((BACKEND, "backend"), (STUDENT, "student"), (ADMIN, "admin")):
        if not folder.exists():
            fail(f"{label}/ folder was not found. Keep run.py in the project root.")
    if not (BACKEND / "requirements.txt").exists():
        fail("backend/requirements.txt not found.")
    if not (STUDENT / "package.json").exists():
        fail("student/package.json not found.")
    if not (ADMIN / "package.json").exists():
        fail("admin/package.json not found.")


def run_command(cmd, cwd, title):
    print(f"[{title}] {' '.join(map(str, cmd))}")
    flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    return subprocess.Popen(
        [str(x) for x in cmd],
        cwd=str(cwd),
        creationflags=flags,
    )


def npm_install(folder, title, npm):
    package_json = folder / "package.json"
    node_modules = folder / "node_modules"
    if not package_json.exists():
        fail(f"{title}: package.json not found in {folder}")
    if node_modules.exists():
        print(f"[{title}] npm dependencies already installed - skipping npm install.")
        return
    print(f"[{title}] Installing npm dependencies...")
    result = subprocess.run([npm, "install"], cwd=str(folder), check=False)
    if result.returncode != 0:
        fail(f"{title} npm install failed with exit code {result.returncode}.")


def backend_dependencies(python):
    # Install backend packages only when FastAPI is unavailable. This keeps repeated starts fast.
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
        import sqlalchemy  # noqa: F401
    except Exception:
        print("[Backend] Python dependencies are missing. Installing backend/requirements.txt...")
        result = subprocess.run(
            [python, "-m", "pip", "install", "-r", str(BACKEND / "requirements.txt")],
            cwd=str(ROOT),
            check=False,
        )
        if result.returncode != 0:
            fail("Backend dependency installation failed. Run `python -m pip install -r backend\\requirements.txt` manually and retry.")


def wait_for_url(process, url, timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process.poll() is not None:
            return False
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.5)
    return False

def stop_processes(processes):
    for process in processes:
        if process.poll() is not None:
            continue
        try:
            if os.name == "nt":
                process.send_signal(signal.CTRL_BREAK_EVENT)
            else:
                process.terminate()
        except Exception:
            try:
                process.terminate()
            except Exception:
                pass


validate_project()
npm = npm_command()
python = sys.executable

print("\n==============================================")
print("        AI EXAM SYSTEM - ONE COMMAND RUNNER")
print("==============================================")
print("Backend : http://127.0.0.1:8000")
print("Student : http://localhost:5173")
print("Admin   : http://localhost:5174")
print("")
print("Demo Student : student1 / student123")
print("Demo Admin   : admin / admin123")
print("==============================================\n")

processes = []
try:
    npm_install(STUDENT, "Student", npm)
    npm_install(ADMIN, "Admin", npm)
    backend_dependencies(python)

    print("\nStarting services...\n")
    processes.append(run_command(
        [python, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"],
        BACKEND,
        "Backend",
    ))
    if not wait_for_url(processes[0], "http://127.0.0.1:8000/health", timeout=20):
        print("\nERROR: Backend failed to start or /health did not respond.")
        print("Check the backend error shown above, then fix it before starting the web panels.")
        raise SystemExit(1)

    processes.append(run_command(
        [npm, "run", "dev", "--", "--host", "127.0.0.1", "--port", "5173"],
        STUDENT,
        "Student",
    ))
    processes.append(run_command(
        [npm, "run", "dev", "--", "--host", "127.0.0.1", "--port", "5174"],
        ADMIN,
        "Admin",
    ))

    if not wait_for_url(processes[1], "http://127.0.0.1:5173/", timeout=20):
        print("\nERROR: Student Vite server failed to start.")
        raise SystemExit(1)
    if not wait_for_url(processes[2], "http://127.0.0.1:5174/", timeout=20):
        print("\nERROR: Admin Vite server failed to start.")
        raise SystemExit(1)

    time.sleep(1)
    print("\n==============================================")
    print("      AI EXAM SYSTEM STARTED SUCCESSFULLY")
    print("==============================================")
    print("Student : http://localhost:5173")
    print("Admin   : http://localhost:5174")
    print("Backend : http://127.0.0.1:8000/health")
    print("")
    print("Student Login : student1 / student123")
    print("Admin Login   : admin / admin123")
    print("==============================================")
    print("Keep this terminal open. Press Ctrl+C to stop all services.\n")

    # Open both web panels automatically after startup.
    try:
        webbrowser.open("http://localhost:5173")
        webbrowser.open("http://localhost:5174")
    except Exception:
        pass

    while True:
        dead = [(name, p.returncode) for name, p in zip(("Backend", "Student", "Admin"), processes) if p.poll() is not None]
        if dead:
            print(f"\nService stopped unexpectedly: {dead}")
            print("The other services will be stopped too.")
            break
        time.sleep(1)

except KeyboardInterrupt:
    print("\nStopping AI Exam System...")
finally:
    stop_processes(processes)
    time.sleep(1)
    print("AI Exam System stopped.")
