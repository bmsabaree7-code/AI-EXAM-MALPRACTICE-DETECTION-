from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from pydantic import BaseModel
from jose import jwt
from datetime import datetime, timedelta
import os, base64, io, hashlib, hmac, secrets, time

try:
    import cv2
    import numpy as np
except Exception:
    cv2 = None
    np = None

DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///./exam.db")
engine=create_engine(DATABASE_URL, connect_args={"check_same_thread":False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine)
Base=declarative_base()
def hash_password(password: str) -> str:
    # PBKDF2 avoids the bcrypt/passlib compatibility issue seen with
    # newer bcrypt releases and Python 3.14.
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310000)
    return "pbkdf2_sha256$310000$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(digest).decode()

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, rounds, salt_b64, digest_b64 = stored.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(rounds))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False
SECRET=os.getenv("SECRET_KEY","dev-secret-change-me")

class User(Base):
    __tablename__="users"
    id=Column(Integer,primary_key=True); username=Column(String,unique=True); password_hash=Column(String); role=Column(String); full_name=Column(String); active=Column(Boolean,default=True)

class Question(Base):
    __tablename__="questions"
    id=Column(Integer,primary_key=True); text=Column(Text); a=Column(String); b=Column(String); c=Column(String); d=Column(String); answer=Column(String)

class SessionExam(Base):
    __tablename__="sessions"
    id=Column(Integer,primary_key=True); student_id=Column(Integer,ForeignKey("users.id")); started=Column(DateTime,default=datetime.utcnow); submitted=Column(DateTime); score=Column(Integer,default=0); status=Column(String,default="in_progress"); result_json=Column(Text,default="{}")

class Violation(Base):
    __tablename__="violations"
    id=Column(Integer,primary_key=True); session_id=Column(Integer); type=Column(String); timestamp=Column(DateTime,default=datetime.utcnow); details=Column(Text,default="")

Base.metadata.create_all(engine)
# Lightweight migration for databases created by earlier project ZIP versions.
try:
    from sqlalchemy import inspect, text as sql_text
    if "result_json" not in {c["name"] for c in inspect(engine).get_columns("sessions")}:
        with engine.begin() as conn:
            conn.execute(sql_text("ALTER TABLE sessions ADD COLUMN result_json TEXT DEFAULT '{}'"))
except Exception:
    pass

app=FastAPI(title="AI Exam System API")
cors=os.getenv("CORS_ORIGINS","*").split(",")
app.add_middleware(CORSMiddleware,allow_origins=cors,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

MALPRACTICE_TYPES = [
    "Face Missing", "Face Mismatch", "Multiple Persons", "Looking Away",
    "Mobile Detected", "Unauthorized Device", "Earphone / Headset",
    "Bit Paper / Notes", "Talking / Suspicious Audio", "Person Entering",
    "Additional Screen", "Unusual Movement", "Mouth Movement / Talking", "Head Movement", "Background Movement", "Camera Obstructed", "Possible Mobile Phone", "Possible Paper / Notes", "Possible Headphones", "Possible Other Device"
]

def seed_data(db):
    if not db.query(User).filter(User.username=="admin").first():
        db.add(User(username="admin",password_hash=hash_password("admin123"),role="admin",full_name="System Administrator"))
    if not db.query(User).filter(User.username=="student1").first():
        db.add(User(username="student1",password_hash=hash_password("student123"),role="student",full_name="Demo Student"))
    if db.query(Question).count()==0:
        rows=[
        ("Which language is used by FastAPI?","Python","Java","C++","PHP","A"),
        ("What does AI stand for?","Applied Input","Artificial Intelligence","Advanced Internet","Auto Interface","B"),
        ("Which protocol is secure web traffic?","HTTP","FTP","HTTPS","SMTP","C"),
        ("Which library is used for computer vision?","OpenCV","React","Express","Laravel","A"),
        ("What is YOLO mainly used for?","Object detection","Database","CSS","Email","A"),
        ("Which database is easiest for local demo?","SQLite","CSS","Redis","HTML","A"),
        ("What is JWT used for?","Authentication","Video editing","Styling","Images","A"),
        ("Which API accesses webcam in browser?","getUserMedia","getSQL","getCameraSQL","openVideo","A"),
        ("MCQ means?","Multiple Choice Question","Machine Code Queue","Media Control Query","Model Camera Quality","A"),
        ("What should remain visible during exam?","Student face","Only keyboard","Nothing","Printer","A")]
        for x in rows: db.add(Question(text=x[0],a=x[1],b=x[2],c=x[3],d=x[4],answer=x[5]))
    db.commit()

@app.on_event("startup")
def startup_seed():
    db=SessionLocal()
    try: seed_data(db)
    finally: db.close()

class Login(BaseModel): username:str; password:str
class Event(BaseModel): session_id:int; type:str; details:str=""
class Submit(BaseModel): session_id:int; answers:dict

@app.get("/health")
def health(): return {"status":"ok","service":"AI Exam System"}

@app.get("/api/seed")
def seed(db:Session=Depends(lambda:SessionLocal())):
    seed_data(db); db.close()
    return {"status":"seeded","student":"student1 / student123","admin":"admin / admin123"}

@app.post("/api/login")
def login(x:Login,db:Session=Depends(lambda:SessionLocal())):
    u=db.query(User).filter(User.username==x.username).first()
    if not u or not verify_password(x.password,u.password_hash): raise HTTPException(401,"Invalid login")
    token=jwt.encode({"sub":u.id,"role":u.role,"exp":datetime.utcnow()+timedelta(hours=12)},SECRET,algorithm="HS256")
    return {"token":token,"role":u.role,"user":{"id":u.id,"name":u.full_name,"username":u.username}}

@app.get("/api/questions")
def questions(db:Session=Depends(lambda:SessionLocal())):
    return [{"id":q.id,"text":q.text,"options":{"A":q.a,"B":q.b,"C":q.c,"D":q.d}} for q in db.query(Question).order_by(Question.id).all()]

@app.post("/api/start/{student_id}")
def start(student_id:int,db:Session=Depends(lambda:SessionLocal())):
    s=SessionExam(student_id=student_id); db.add(s); db.commit(); db.refresh(s); return {"session_id":s.id}

@app.post("/api/event")
def event(x:Event,db:Session=Depends(lambda:SessionLocal())):
    if x.type not in MALPRACTICE_TYPES:
        raise HTTPException(400, f"Unknown malpractice type. Allowed: {MALPRACTICE_TYPES}")
    v=Violation(session_id=x.session_id,type=x.type,details=x.details); db.add(v); db.commit(); return {"ok":True,"type":x.type,"timestamp":v.timestamp.isoformat()}

@app.post("/api/submit")
def submit(x:Submit,db:Session=Depends(lambda:SessionLocal())):
    s=db.get(SessionExam,x.session_id)
    if not s: raise HTTPException(404,"Exam session not found")
    qs=db.query(Question).order_by(Question.id).all()
    correct=sum(1 for q in qs if x.answers.get(str(q.id)) == q.answer)
    answered=sum(1 for q in qs if x.answers.get(str(q.id)) in ("A","B","C","D"))
    wrong=answered-correct
    unanswered=len(qs)-answered
    s.score=correct;s.status="completed";s.submitted=datetime.utcnow()
    s.result_json=__import__("json").dumps({"answers":x.answers,"correct":correct,"wrong":wrong,"answered":answered,"unanswered":unanswered,"total":len(qs)})
    db.commit()
    return {"score":correct,"correct":correct,"wrong":wrong,"answered":answered,"unanswered":unanswered,"total":len(qs),"status":"completed"}

@app.get("/api/malpractice-types")
def malpractice_types():
    return MALPRACTICE_TYPES

class Frame(BaseModel):
    image:str

# Optional YOLO object detection. If ultralytics/model download is unavailable, face/motion checks still work.
_detector = None
_detector_attempted = False
_previous_frames = {}
_previous_face_centres = {}

class Frame(BaseModel):
    image: str
    session_id: int | None = None

@app.post("/api/detect/frame")
def detect_frame(x: Frame):
    """Computer-vision screening; possible violations are review signals, not proof."""
    global _detector, _detector_attempted
    if cv2 is None or np is None:
        return {"available":False,"events":[],"message":"OpenCV is not available"}
    try:
        raw=x.image.split(',',1)[-1]
        frame=cv2.imdecode(np.frombuffer(base64.b64decode(raw),np.uint8),cv2.IMREAD_COLOR)
        if frame is None: raise ValueError("Invalid camera frame")
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        cascade=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
        faces=cascade.detectMultiScale(gray,1.12,5,minSize=(45,45))
        events=[]
        if len(faces)==0: events.append("Face Missing")
        elif len(faces)>1: events.append("Multiple Persons")
        key=str(x.session_id or "prelogin")
        prev=_previous_frames.get(key)
        if len(faces)==1:
            fx,fy,fw,fh=map(int,faces[0])
            centre=(fx+fw//2,fy+fh//2)
            oldc=_previous_face_centres.get(key)
            if oldc and (abs(centre[0]-oldc[0])>max(22,frame.shape[1]*0.09) or abs(centre[1]-oldc[1])>max(22,frame.shape[0]*0.09)):
                events.append("Head Movement")
            lower=gray[fy+int(fh*.55):min(fy+fh,gray.shape[0]),fx:min(fx+fw,gray.shape[1])]
            oldlower=_previous_frames.get(key+"_mouth")
            if oldlower is not None and lower.size and oldlower.shape==lower.shape and float(np.mean(cv2.absdiff(lower,oldlower)))>17:
                events.append("Mouth Movement / Talking")
            _previous_frames[key+"_mouth"]=lower.copy()
            _previous_face_centres[key]=centre
        if prev is not None and prev.shape==gray.shape:
            diff=cv2.absdiff(gray,prev)
            mask=np.ones(gray.shape,dtype=np.uint8)*255
            for fx,fy,fw,fh in faces:
                mask[max(0,fy-10):min(mask.shape[0],fy+fh+10),max(0,fx-10):min(mask.shape[1],fx+fw+10)]=0
            mask_count=max(1,cv2.countNonZero(mask))
            changed=cv2.threshold(cv2.bitwise_and(diff,diff,mask=mask),24,255,cv2.THRESH_BINARY)[1]
            motion=cv2.countNonZero(changed)/mask_count
            if motion>0.055: events.append("Background Movement")
        _previous_frames[key]=gray.copy()
        detections=[]
        if not _detector_attempted:
            _detector_attempted=True
            try:
                from ultralytics import YOLO
                _detector=YOLO(os.getenv("YOLO_MODEL","yolov8n.pt"))
            except Exception:
                _detector=None
        if _detector is not None:
            try:
                result=_detector.predict(frame,verbose=False,conf=0.38,imgsz=320)[0]
                for box in result.boxes:
                    detections.append(str(result.names.get(int(box.cls[0]),"")).lower())
                if "cell phone" in detections: events.append("Possible Mobile Phone")
                if any(v in detections for v in ("book","scissors")): events.append("Possible Paper / Notes")
                if any(v in detections for v in ("laptop","tv","remote")): events.append("Possible Other Device")
            except Exception: pass
        return {"available":True,"face_count":int(len(faces)),"events":list(dict.fromkeys(events)),"objects":detections,
                "object_model_available":_detector is not None,
                "note":"Object detection is model-dependent. Phone cases, loose paper and headphones may be missed; review all flags manually."}
    except Exception as e:
        return {"available":False,"events":[],"message":str(e)}

@app.get("/api/admin/stats")
def stats(db:Session=Depends(lambda:SessionLocal())):
    return {"students":db.query(User).filter(User.role=="student").count(),"sessions":db.query(SessionExam).count(),"completed":db.query(SessionExam).filter(SessionExam.status=="completed").count(),"violations":db.query(Violation).count()}

@app.get("/api/admin/students")
def students(db:Session=Depends(lambda:SessionLocal())):
    return [{"id":u.id,"name":u.full_name,"username":u.username,"active":u.active} for u in db.query(User).filter(User.role=="student").all()]

@app.get("/api/admin/sessions")
def admin_sessions(db:Session=Depends(lambda:SessionLocal())):
    rows=[]
    for exam in db.query(SessionExam).order_by(SessionExam.started.desc()).all():
        user=db.get(User,exam.student_id)
        try: result=__import__("json").loads(exam.result_json or "{}")
        except Exception: result={}
        total=result.get("total",db.query(Question).count())
        answered=result.get("answered",0); correct=result.get("correct",exam.score or 0)
        wrong=result.get("wrong",0); unanswered=result.get("unanswered",max(0,total-answered))
        rows.append({"session_id":exam.id,"student_id":exam.student_id,"student":user.full_name if user else "Unknown",
          "username":user.username if user else "","started":exam.started.isoformat() if exam.started else None,
          "submitted":exam.submitted.isoformat() if exam.submitted else None,"status":exam.status,
          "total":total,"answered":answered,"unanswered":unanswered,"correct":correct,"wrong":wrong,"score":f"{correct}/{total}"})
    return rows

@app.get("/api/admin/violations")
def violations(db:Session=Depends(lambda:SessionLocal())):
    return [{"id":v.id,"session":v.session_id,"type":v.type,"time":v.timestamp.isoformat(),"details":v.details} for v in db.query(Violation).order_by(Violation.timestamp.desc()).all()]
